﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MoveEstimatorGUI
{
    public partial class MoveEstimatorGUI : Form
    {
        public MoveEstimatorGUI()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double numberOfHours = double.Parse(textBox1.Text);
            double numberOfmiles = double.Parse(textBox2.Text);
            double totalFee = 200 + 150 * numberOfHours + 2 * numberOfmiles;
            label2.Text = label2.Text + totalFee.ToString();
        }
    }
}
