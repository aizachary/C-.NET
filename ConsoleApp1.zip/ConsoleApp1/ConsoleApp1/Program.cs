﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Lyrics
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Smoke Alarm by Carsie Blanton");
            Console.WriteLine("Why do you waste your time,");
            Console.WriteLine("Thinkin' 'bout your reputation,");
            Console.WriteLine("Tryin' to meet an expectation,");
            Console.WriteLine("Wondering what they're gonna say.");
        }
    }
}
