﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InchestoCentimetersGUI
{
    public partial class InchestoCentimetersGUI : Form
    {
        public InchestoCentimetersGUI()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double centimeters;
            double inches = double.Parse(textBox1.Text);
            centimeters = 2.54 * inches;
            Label2.Text = label2.Text + centimeters.ToString();
        }
    }
}
