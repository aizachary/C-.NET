﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace PersonalInfo
{
    class Program
    {
        static void Main(string[] args)
            {
                Console.WriteLine("Name: Anna Zachary");
                Console.WriteLine("Birthday: 5/17/1984");
                Console.WriteLine("Work Phone Number: 7045554545");
                Console.WriteLine("Work Phone Number: 9802950394");
            }
    }
}

